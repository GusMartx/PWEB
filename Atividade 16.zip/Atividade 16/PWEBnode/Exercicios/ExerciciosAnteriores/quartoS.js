const fs = require('fs');
const data = fs.readFileSync('arquivo.txt');
console.log(data.toString());